import torch.cuda
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
from torchvision import datasets,transforms
from net import Model
import torch.optim as optim

writer = SummaryWriter(log_dir='logs')

# transforms - preprocess training data
train_transform = transforms.Compose([
    transforms.RandomHorizontalFlip(),
    transforms.RandomCrop(32,padding=4),
    transforms.ToTensor(),  # 转成tensor 数据类型
    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
])

test_transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
])
#  Get the dataset
#  train_dataset
train_data_set = datasets.CIFAR10('./dataset', train=True, transform=train_transform, download=True)

#  test_dataset
test_data_set = datasets.CIFAR10('./dataset', train=False, transform=test_transform, download=True)

#  size of dataset
train_data_size = len(train_data_set)
test_data_size = len(test_data_set)

# load the dataset
train_data_loader = DataLoader(train_data_set, batch_size=64, shuffle=True)   # 一批64个，打乱数据进行处理
test_data_loader = DataLoader(test_data_set, batch_size=64, shuffle=True)

# define the net
Model = Model()

# check gpu
use_gpu = torch.cuda.is_available()
if use_gpu:
    print("gpu_available")
    Model = Model.cuda()
else:
    print("cpu")

#
epochs = 150

# loss function
lossFn = torch.nn.CrossEntropyLoss()  # CrossEntropyLoss() for classification

# set optimizer
optimizer = optim.SGD(Model.parameters(), lr=0.01)  # SGD for gradient descent

for epoch in range(epochs):
    print("训练轮数{}/{}".format(epoch+1, epochs))   # epoch +1

    # Initialization
    train_total_loss = 0.0
    test_total_loss = 0.0
    train_total_acc = 0.0
    test_total_acc = 0.0

    # training loop
    for data in train_data_loader:
        inputs, labels = data
        if use_gpu:
            inputs = inputs.cuda()
            labels = labels.cuda()

        optimizer.zero_grad()   # zeroes the gradients
        outputs = Model(inputs)

        # Computes loss
        loss = lossFn(outputs, labels)

        loss.backward()  # backpropagates gradients
        optimizer.step()  # Updates parameters

        # accumulates loss and accuracy for training
        _, index = torch.max(outputs, 1) # 得到预测值最大的下标
        acc = torch.sum(index == labels).item()

        train_total_loss += loss.item()
        train_total_acc += acc

    # testing loop - 和training loop 相似 （剔除反向传播)
    with torch.no_grad():
        for data in test_data_loader:
            inputs, labels = data
            if use_gpu:
                inputs = inputs.cuda()
                labels = labels.cuda()
            outputs = Model(inputs)

            loss = lossFn(outputs, labels)

            _, index = torch.max(outputs, 1)
            acc = torch.sum(index == labels).item()

            test_total_loss += loss.item()
            test_total_acc += acc

    print("train loss:{},acc:{} test loss:{},acc:{}".format(train_total_loss, train_total_acc/train_data_size, test_total_loss, test_total_acc/test_data_size))
    writer.add_scalar('loss/train', train_total_loss, epoch+1)
    writer.add_scalar('acc/train', train_total_acc/train_data_size, epoch+1)
    writer.add_scalar('loss/test', test_total_loss, epoch+1)
    writer.add_scalar('acc/test', test_total_acc/test_data_size, epoch+1)

    if((epoch+1) % 50 == 0):
        torch.save(Model, "model/model_{}.pth".format(epoch+1))






