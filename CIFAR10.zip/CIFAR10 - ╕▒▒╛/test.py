import os
import cv2
import torch
from torchvision import transforms


classes = ['airplane', 'automobile', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck']

use_gpu = torch.cuda.is_available()
model = torch.load("./model/model_150.pth", map_location=torch.device('cuda' if use_gpu else 'cpu'))

test_transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
])

# 指定文件夹
folder_path ='./testimages'
files = os.listdir(folder_path)

#得到每个文件的地址
images_files = [os.path.join(folder_path, f)for f in files]
print(images_files)

for img in images_files:
    image = cv2.imread(img) #读取图片
    cv2.imshow('image', image) #显示图片
    image = cv2.resize(image, (32, 32))
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    image = test_transform(image)  # 进行transform处理，得到tensor数据类型
    image = torch.reshape(image,(1,3,32,32))
    image = image.to('cuda' if use_gpu else 'cpu')
    output = model(image)

    value, index = torch.max(output,1)
    pre_val = classes[index]
    true_class = img.split('\\')[-1].split('.')[0]
    correct = '正确' if pre_val == true_class else '错误'

    print('预测概率:{},预测下标:{},预测结果:{},真实类型:{},预测{}'.format(value.item(), index.item(), pre_val, true_class, correct))
    #等待用户按键
    cv2.waitKey(0)